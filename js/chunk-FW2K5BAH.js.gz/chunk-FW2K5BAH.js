function r(o,e,n){return o?e():n?.()}export{r as a};
